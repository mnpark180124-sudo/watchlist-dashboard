import json, os
from datetime import datetime, timezone, timedelta
import yfinance as yf

MARKETS = {
    "sox": ("^SOX", "반도체(SOX)"), "technology": ("XLK", "미국 기술(XLK)"),
    "financial": ("XLF", "미국 금융(XLF)"), "energy": ("XLE", "미국 에너지(XLE)"),
    "industrial": ("XLI", "미국 산업재(XLI)"), "materials": ("XLB", "미국 소재(XLB)"),
    "healthcare": ("XLV", "미국 헬스케어(XLV)"), "discretionary": ("XLY", "미국 경기소비재(XLY)"),
    "staples": ("XLP", "미국 필수소비재(XLP)"), "communication": ("XLC", "미국 커뮤니케이션(XLC)"),
    "realestate": ("XLRE", "미국 부동산(XLRE)"), "utilities": ("XLU", "미국 유틸리티(XLU)"),
    "nasdaq": ("^IXIC", "NASDAQ"), "sp500": ("^GSPC", "S&P 500")
}
STOCK_MAP = {
 "005930":["sox","technology","nasdaq"], "005935":["sox","technology","nasdaq"], "000660":["sox","technology","nasdaq"],
 "006400":["technology","materials","nasdaq"], "0117V0":["industrial","sp500"], "395160":["industrial","sp500"],
 "079550":["industrial","sp500"], "267270":["industrial","sp500"], "443060":["industrial","sp500"], "010060":["energy","industrial","sp500"],
 "456040":["energy","industrial","sp500"], "298020":["materials","industrial","sp500"], "006260":["materials","industrial","sp500"],
 "028050":["industrial","sp500"], "278470":["industrial","sp500"], "161890":["industrial","sp500"], "237690":["industrial","sp500"],
 "036620":["industrial","sp500"], "336260":["industrial","sp500"], "034020":["industrial","utilities","sp500"], "222080":["industrial","sp500"],
 "011500":["materials","sp500"], "023160":["materials","sp500"], "214430":["materials","sp500"], "009520":["materials","sp500"],
 "356860":["materials","sp500"], "373220":["materials","sp500"], "086520":["materials","technology","nasdaq"], "003670":["materials","technology","nasdaq"],
 "105560":["financial","sp500"], "055550":["financial","sp500"], "086790":["financial","sp500"],
 "005380":["discretionary","industrial","sp500"], "000270":["discretionary","industrial","sp500"], "012330":["discretionary","industrial","sp500"]
}

def quote(ticker,label):
    try:
        h=yf.Ticker(ticker).history(period="5d", auto_adjust=False)
        closes=[float(x) for x in h["Close"].dropna().tolist()]
        if len(closes)<2: raise ValueError("최근 2개 거래일 데이터 부족")
        prev,last=closes[-2],closes[-1]
        return {"ticker":ticker,"label":label,"price":round(last,2),"change":round(last-prev,2),"changeRate":round((last/prev-1)*100,2),"ok":True}
    except Exception as e:
        print(f"[야간시장 실패] {label}({ticker}): {e}")
        return {"ticker":ticker,"label":label,"price":None,"change":None,"changeRate":None,"ok":False}

def main():
    kst=timezone(timedelta(hours=9)); now=datetime.now(kst)
    data={"version":"V4-4.6","updatedAtKST":now.strftime("%Y-%m-%d %H:%M"),"markets":{},"stockMap":STOCK_MAP}
    for key,(ticker,label) in MARKETS.items(): data["markets"][key]=quote(ticker,label)
    os.makedirs("data",exist_ok=True)
    with open("data/sector-night.json","w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False)
    print(f"야간 관련시장 {sum(x['ok'] for x in data['markets'].values())}/{len(MARKETS)}개 수집")
if __name__=="__main__": main()
